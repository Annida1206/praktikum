<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function infoLogin()
{
    $CI = &get_instance();
    return $CI->session->userdata('user_login'); // sesuaikan jika Anda pakai 'username' atau lainnya
}
