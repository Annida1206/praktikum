<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('kategori_model');
        $this->load->helper('user'); 
        $this->load->library('form_validation');
    }

    public function index() {
        $data = array(
            'title' => 'View Data Kategori',
            'userlog' => infoLogin(),
            'kategori' => $this->kategori_model->getAll(),
            'content' => 'kategori/index'
        );
        $this->load->view('template/main', $data);
    }

    public function add() {
        $data = array(
            'title' => 'Tambah Data Kategori',
            'content' => 'kategori/add_form'
        );
        $this->load->view('template/main', $data);
    }

    public function save() 
    {
        $this->kategori_model->Save();
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata("success", "Data Kategori Berhasil Disimpan");
        }
        redirect('kategori');
    }
    public function getedit($id) 
    {
        $data = array(
            'title' => 'Update Data Kategori',
            'kategori' => $this->kategori_model->getById($id),
            'content' => 'kategori/edit_form'
        );
        $this->load->view('template/main', $data);       
    }
    public function edit() 
    {
        $this->kategori_model->editData();
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata("success", "Data Kategori Berhasil DiUpdate");
        }
        redirect('kategori');
    }
    function delete($id)
    {
        $this->kategori_model->delete($id);
        redirect('kategori');
    }
    public function add() {
        $data = array(
            'title' => 'Tambah Data Barang',
            'kategori' => $this->db->gt('kategori')->result_array(),
            'satuan' => $this->db->gt('satuan')->result_array(),
            'supplier' => $this->db->gt('supplier')->result_array(),
            'content' => 'barang/add_form'
        );
        $this->load->view('template/main', $data);
    }
    public function save() 
    {
        $this->Barang_model->Save();
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata("success", "Data Kategori Berhasil Disimpan");
        }
        redirect('barang')
    }
}