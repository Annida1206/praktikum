<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Kustomer extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function index() {
        echo "Ini index Kustomer";
    }

    public function laporan() {
        $data = array(
            'title' => 'Tambah Data Laporan kustomer',
            'content' => 'kustomer/laporan'
        );
        $this->load->view('template/main', $data);
    }

    public function headerlap() {
        $this->load->view('kustomerlap/report_header_only');
    }
    

}
