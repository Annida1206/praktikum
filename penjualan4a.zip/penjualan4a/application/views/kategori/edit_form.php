<main>
    <div class="container-fluid">
        <h1 class="card mt-4"></h1>
        <nav aria-label="breadcrumb">
        <ol class="breadcrumb mt-2 mb-3">
            <li class="breadcrumb-item">
            <a href="<?php echo site_url('kategori'); ?>">Kategori</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
            <?php echo $title ?>
            </li>
        </ol>
        </nav>
        <div class="mb-4">
            <div class="card-body">
            <form action="<?php echo site_url('kategori/edit'); ?>" method="post">

            <div class="form-floating mb-3">
                <input class="form-control" type="hidden" name="id" value="<?php echo $kategori->id; ?>" required />
                <input class="form-control <?php echo form_error('name') ? 'is-invalid' : ''; ?>" 
                    type="text" name="name" value="<?php echo $kategori->name; ?>" placeholder="Nama" required />
                <label for="username">Name <code>*</code></label>
                <div class="invalid-feedback">
                    <?php echo form_error('name'); ?>
                </div>
            </div>
                <button class="btn btn-primary" type="submit"><i class="fas fa-plus"></i> Save</button>
        </form>
        </div>
        </div>
        <div style="height: 100vh"></div>
    </div>
</main>
