<main>
    <div class="container-fluid">
        <h1 class="mt-4"><?php echo $title; ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mt-2 mb-3">
                <li class="breadcrumb-item">
                    <a href="<?php echo site_url('kategori'); ?>">Kategori</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <?php echo $title; ?>
                </li>
            </ol>
        </nav>

        <div class="card mb-4">
            <div class="card-body">
                <form action="<?php echo site_url('barang/save'); ?>" method="post">
                    <input type="hidden" name="id" value="<?= $barang->id; ?>" required />

                    <div class="mb-3">
                        <label>Barcode</label>
                        <input class="form-control" name="barcode" value="<?= $barang->barcode; ?>" type="text" placeholder="Barcode" required>
                    </div>

                    <div class="mb-3">
                        <label>Nama Barang</label>
                        <input class="form-control" name="nama" value="<?= $barang->nama; ?>" type="text" placeholder="Nama Barang">
                    </div>

                    <div class="mb-3">
                        <label>Harga Beli</label>
                        <input class="form-control" name="harga_beli" value="<?= $barang->harga_beli; ?>" type="text" placeholder="Harga beli">
                    </div>

                    <div class="mb-3">
                        <label>Harga Jual</label>
                        <input class="form-control" name="harga_jual" value="<?= $barang->harga_jual; ?>" type="text" placeholder="Harga jual">
                    </div>

                    <div class="mb-3">
                        <label>Stok</label>
                        <input class="form-control" name="stok" value="<?= $barang->stok; ?>" type="text" placeholder="Stok" disabled>
                    </div>

                    <div class="mb-3">
                        <label>Kategori</label>
                        <select name="kategori_id" class="form-control" required>
                            <?php foreach($kategori as $kat): ?>
                                <option value="<?php echo $kat['id']; ?>" <?= ($barang->kategori_id == $kat['id']) ? 'selected' : ''; ?>>
                                    <?php echo $kat['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Satuan</label>
                        <select name="satuan_id" class="form-control" required>
                            <?php foreach($satuan as $sat): ?>
                                <option value="<?php echo $sat['id']; ?>" <?= ($barang->satuan_id == $sat['id']) ? 'selected' : ''; ?>>
                                    <?php echo $sat['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Supplier</label>
                        <select name="supplier_id" class="form-control" required>
                            <?php foreach($supplier as $sup): ?>
                                <option value="<?php echo $sup['id']; ?>" <?= ($barang->supplier_id == $sup['id']) ? 'selected' : ''; ?>>
                                    <?php echo $sup['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button class="btn btn-warning" type="submit">
                        <i class="fas fa-plus"></i> Update
                    </button>
                </form>
            </div>
        </div>
    </div>
</main>
